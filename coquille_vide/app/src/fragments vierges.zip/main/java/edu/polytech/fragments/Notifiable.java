package edu.polytech.fragments;

public interface Notifiable {
    void onClick(int numFragment);
    void onDataChange(int numFragment, Object object);
}
