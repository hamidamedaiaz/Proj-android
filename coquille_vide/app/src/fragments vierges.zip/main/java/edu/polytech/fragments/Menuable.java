package edu.polytech.fragments;

public interface Menuable {
    void onMenuChange(int index);
}
